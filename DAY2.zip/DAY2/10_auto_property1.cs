class Example
{
    private int data1 = 0;

    public int Data1
    {
        set => data1 = value;
        get => data1;
    }	
}

class Program
{
    public static void Main()
    {
        Example e = new Example();

    }
}
