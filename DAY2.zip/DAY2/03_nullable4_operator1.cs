using static System.Console;

int? n1 = null;

int a = n1;


