class Program
{
    public static void M1(int a, int b) { }

    public static void Main()
    {
        M1(1, 2);
	
    }
//  public static void M3(int[] ar, int n) { }			
//  public static void M4(params int[] ar, int n) { }	

}
	