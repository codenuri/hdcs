using static System.Console;

class Program
{

	public static void Main()
	{
		int x = 1;
		int y = 2;

		Swap(x, y);

		WriteLine($"{x}, {y}");
				//   2,   1
	}
}