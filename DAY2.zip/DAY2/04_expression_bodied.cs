﻿using System;

//46 page 오른쪽
class Program
{
    public static int Square1(int x)
    {
        return x * x;
    }

    public static void Main()
    {
        int ret = Square1(3);
    }
}