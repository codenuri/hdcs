﻿// 51 page ~ 
class Program
{
    public static void SetRect(int x,     int y, 
							   int width, int height) {}

    public static void Main()
    {
        SetRect(10, 10, 30, 30);
					
 						
    }
}
