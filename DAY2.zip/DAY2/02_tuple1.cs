using static System.Console;
// 35 page

// #1. variable, array, tuple
int n1 = 0;
int[] a1 = { 1, 2, 3 };
(int, double, char) t1 = (3, 4.5, 'A');

