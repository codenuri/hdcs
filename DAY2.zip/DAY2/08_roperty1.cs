﻿// 82 page
// 핵심 #1. private vs public
// 핵심 #2. setter & getter

class Person1
{
    public int age;
}

class Program
{
    public static void Main()
    {
        Person1 p1 = new Person1();
        
		p1.age = 10;
    }
}
