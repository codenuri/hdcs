class Person
{
    private int age = 0;    

}

class Program
{
    public static void Main()
    {
        Person p1 = new Person();

    }
}
