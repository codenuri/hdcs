string s1 = "hello";
string s2 = null;

var ret1 = s1.Length;
var ret2 = s2.Length;


int  n1 = 10;
int? n2 = null;


string s3 = null;


