﻿using static System.Console;


class Program
{
    public static void Main()
    {

    }
}


