int    n = 0;
double d = 0;
string s = "A";

object o1 = n;
object o2 = d;
object o3 = s;

System.Object o4 = n;
System.Object o5 = d;
System.Object o6 = s;