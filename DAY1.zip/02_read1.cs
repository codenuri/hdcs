using System;

// Console.ReadLine

Console.Write("input your name >> ");

 
      
  
  
   