
// casting
double d = 3.4;
int n1 = d;		// ?

