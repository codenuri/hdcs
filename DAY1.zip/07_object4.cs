using static System.Console;

string s = "abcd";

// method, property

bool b = s.Contains('b');
int  n = s.Length;       

WriteLine($"{b} {n}");

