﻿using static System.Console;

int n1 = 10;
int n2 = 20;


