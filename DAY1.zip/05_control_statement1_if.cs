using static System.Console;

int score = 75;

if ( score > 70 ) 
{
	WriteLine("pass");
}
else if ( score == 70 )
{
	WriteLine("reexam");
}
else 
{
	WriteLine("fail");
}

if ( score ) { } // error
