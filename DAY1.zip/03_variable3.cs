// 변수의 초기값을 지정하는 방법.

int n1;		// 초기화 안됨.

int n2 = 0;
int n3 = new int();

int n4 = default(int); 
int n5 = default;	   

var v1 = default(int); 
var v2 = default;	   

