using System;

Console.Write("input yout age >> ");

string s = Console.ReadLine(); // "10"





