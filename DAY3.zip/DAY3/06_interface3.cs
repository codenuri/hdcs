using System.Text;
using static System.Console;

class Program
{
    public static void Main()
    {
        string s1 = "abcd";
        string s2 = s1;

        StringBuilder sb1 = new StringBuilder("abcd");
        StringBuilder sb2 = sb1;
    }
}
