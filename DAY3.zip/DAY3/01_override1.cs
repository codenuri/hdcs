using static System.Console;

// 72 page
class Animal           
{
    public void Cry1() { WriteLine("1. Animal Cry");}
}
class Dog : Animal
{
    public void Cry1() { WriteLine("2. Dog Cry");}
}

class Program
{
    public static void Main()
    {
		Animal a = new Animal(); 
		Dog    d = new Dog();

        a.Cry1();
        d.Cry1();

        
	}
}

