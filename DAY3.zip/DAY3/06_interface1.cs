using static System.Console;

// 75 page

class Camera
{
	public void Take() { WriteLine("take picture"); }
}
class People
{
	public void UseCamera(Camera c) { c.Take(); }
}

class Program 
{
	public static void Main()
	{
		People p = new People();

		Camera c = new Camera();

		p.UseCamera(c);
    }
}
