using System;
using static System.Console;

// 129 page
class Program
{
	public static void Main()
	{
		// ? �� ������ ���ô�.
		? n = 10;
		? d = 3.4;
		? s = "abc";	

		? f = Foo;
	}

	public static void Foo(int arg)
	{
		WriteLine($"Foo : {arg}");
	}
}
