using System;
using static System.Console;

class Program
{
    public static int Max(int a, int b)
    {
        return a < b ? b : a;
    }

    public static void Main()
    {
        int n1 = 10, n2 = 20;

        string s1 = "AA", s2 = "BB";

        int ret1 = Max(n1, n2);
        string ret2 = Max(s1, s2);
    }
}
