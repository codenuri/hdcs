#nullable disable
using System;
using static System.Console;

class Program
{
    public static void Main()
    {
        int n1 = 10, n2 = 20;

        string s1 = "AA", s2 = "BB";

        // ũ�� �� ���
        bool b1 = n1 < n2;

        bool b3 = s1 < s2;
    }
}
