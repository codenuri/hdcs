﻿using static System.Console;

class Program
{
    public static int Add(int a, int b) { return a + b; }

    public static void Main()
    {
        Func<int, int, int> f1 = Add;

    }
}