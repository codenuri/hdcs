﻿using static System.Console;

class Program
{
    public static void Main()
    {
        Car c = new Car();
        c.Color = 10;
        c.Speed = 10;

        c.Go();
        c.Stop();
    }
}