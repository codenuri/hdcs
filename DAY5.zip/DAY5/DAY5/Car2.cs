﻿using static System.Console;

partial class Car
{
    public int Color { get; set; } = 0;

    public void Stop() { WriteLine("Car Stop"); }
}