﻿using static System.Console;

partial class Car
{
    public int Speed { get; set; } = 0;

    public void Go() { WriteLine("Car Go"); }
}