﻿using static System.Console;

class Program
{    
    public static void Main()
    {
        string s = "abcd";

        string s1 = "abcd";
        string s2 = new string("abcd");

    }
}