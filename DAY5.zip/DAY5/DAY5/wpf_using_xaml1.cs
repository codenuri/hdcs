﻿using System;
using System.Windows;
using System.Windows.Controls;
using static System.Net.Mime.MediaTypeNames;


// 모든 UI 를 코드로 직접 작성하는 코드
class MainWindow : Window
{
    public MainWindow()
    {
        Grid grid = new Grid();

        this.Content = grid;

        grid.RowDefinitions.Add(new RowDefinition());
        grid.RowDefinitions.Add(new RowDefinition());
        grid.ColumnDefinitions.Add(new ColumnDefinition());
        grid.ColumnDefinitions.Add(new ColumnDefinition());

        Button btn1 = new Button { Content = "btn1" };
        Button btn2 = new Button { Content = "btn2" };

        Grid.SetRow(btn1, 0);
        Grid.SetColumn(btn1, 0);

        Grid.SetRow(btn2, 1);
        Grid.SetColumn(btn2, 1);

        grid.Children.Add(btn1);
        grid.Children.Add(btn2);

        StackPanel sp = new StackPanel();

        Grid.SetRow(sp, 0);
        Grid.SetColumn(sp, 1);

        grid.Children.Add(sp);

        sp.Children.Add(new Button { Content = "btn3" });
        sp.Children.Add(new Button { Content = "btn4" });
        sp.Children.Add(new Button { Content = "btn5" });

    }
}









class App : Application
{
    public App()
    {
    }

    [STAThread]
    public static void Main()
    {
        App app = new App();
        MainWindow w = new MainWindow();
        w.Show();
        app.Run();
    }
}


// http://schemas.microsoft.com/winfx/2006/xaml/presentation