delegate void MyFunc(int arg);

// ?.invoke()

class Program
{
	public static void M1(int arg)    {}
	
	public static void Main()
	{
		MyFunc f = M1;

		f(10);
		f.Invoke(10);

	}
}
