﻿using static System.Console;

class People
{
    private string name;
    private int age;

    public void SetAge(int age)
    {
        age = age;
    }
    public void SetName(string name)
    {
        name = name;
    }
}

class Program
{
    public static void Main()
    {
        People p = new People();

        

    }
}
