﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SECTION4_EVENT
{
    /// <summary>
    /// Event1.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Event1 : Window
    {
        public Event1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("button1 click");
        }
        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            // 55 page
            // sender : 이벤트를 발생시킨 객체의 참조
            Button button = (Button)sender;

            // 이제 다양한 속성등을 사용해서 확인하면 됩니다.
            // => 이경우는 대부분 Tag 속성으로 구별하는 것이 안전합니다.
            // => Tag 는 object 타입이므로 == 연산자를 사용하려면
            //    해당 타입(string) 으로 캐스팅해서 조사하세요
            //  object 의 == : 동일 객체 조사
            //  string 의 == : 동일 문자열 조사
            if ((string)(button.Tag) == "1") 
                Console.WriteLine("button2 click");
            else
                Console.WriteLine("button3 click");
        }
    }
}
