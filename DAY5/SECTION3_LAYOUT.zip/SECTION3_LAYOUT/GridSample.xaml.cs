﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SECTION3_LAYOUT
{
    /// <summary>
    /// GridSample.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class GridSample : Window
    {
        public GridSample()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Grid.SetRow(button1, 1);
            Grid.SetColumn(button1, 0);
        }
        private void button2_Click(object sender, RoutedEventArgs e)
        {

        // Grid 에 col=0, row=1 에 어떤 컨트롤이 있는 알고 싶다...
            Button button = grid.Children.Cast<Button>().FirstOrDefault(
            btn => Grid.GetRow(btn) == 1 &&  Grid.GetColumn(btn) == 0);
            if (button != null)
            {
                Grid.SetRow(button, 0);
                Grid.SetColumn(button, 0);
            }
            else
            {
                MessageBox.Show("0,1 에 버튼이 없음");
            }
        }
    }
}
