﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SECTION3_LAYOUT
{
    /// <summary>
    /// Canvas.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Canvas : Window
    {
        public Canvas()
        {
            InitializeComponent();
            /*
            Button btn = new Button();
            btn.Content = "확인";
            btn.Width = 100;
            Canvas.SetTop(btn, 30);
            Canvas.SetLeft(btn, 30);
            canvas.Children.Add(btn);
            */
        }
    }
}
