﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SECTIONI7_BIND
{
    /// <summary>
    /// DataBinding.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class DataBinding : Window
    {
        private List<String> st = new List<String>();

        public DataBinding()
        {
            InitializeComponent();

            // listbox에 항목 추가하는 코드
            // listbox.Items.Add("AA");
            // listbox.Items.Add("BB");

            st.Add("AAA");
            st.Add("BBB");
            st.Add("CCC");

            listbox.ItemsSource = st;
        }
    }
}
