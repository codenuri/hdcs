﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SECTION5_RESOURCE
{
    /// <summary>
    /// Resource.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Resource : Window
    {
        public Resource()
        {
            InitializeComponent();
        }

        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            this.Resources["mybrush"] = new SolidColorBrush(Colors.Red);
        }
    }
}
// static resource : resource 에 있는 객체의 복사본으로 적용
// dynamic resource : resource 에 있는 객체의 참조로 적용
//                    resource 의 객체가 변경되면 버튼의 배경색도 즉시 변경